function nigeria() {
  var nige = document.getElementById("nig");
  if (nige.style.display === "none") {
    nige.style.display = "block";
  } else {
    nige.style.display = "none";
  }
}

function brazil() {
  var braz = document.getElementById("bra");
  if (braz.style.display === "none") {
    braz.style.display = "block";
  } else {
    braz.style.display = "none";
  }
}

function france() {
  var nige = document.getElementById("fra");
  if (nige.style.display === "none") {
    nige.style.display = "block";
  } else {
    nige.style.display = "none";
  }
}

function england() {
  var braz = document.getElementById("eng");
  if (braz.style.display === "none") {
    braz.style.display = "block";
  } else {
    braz.style.display = "none";
  }
}

function spain() {
  var nige = document.getElementById("spa");
  if (nige.style.display === "none") {
    nige.style.display = "block";
  } else {
    nige.style.display = "none";
  }
}

function iran() {
  var braz = document.getElementById("ira");
  if (braz.style.display === "none") {
    braz.style.display = "block";
  } else {
    braz.style.display = "none";
  }
}

function mexico() {
  var nige = document.getElementById("mex");
  if (nige.style.display === "none") {
    nige.style.display = "block";
  } else {
    nige.style.display = "none";
  }
}

function croatia() {
  var braz = document.getElementById("cro");
  if (braz.style.display === "none") {
    braz.style.display = "block";
  } else {
    braz.style.display = "none";
  }
}



function egypt() {
  var braz = document.getElementById("egy");
  if (braz.style.display === "none") {
    braz.style.display = "block";
  } else {
    braz.style.display = "none";
  }
}


function croatia() {
  var nige = document.getElementById("cro");
  if (nige.style.display === "none") {
    nige.style.display = "block";
  } else {
    nige.style.display = "none";
  }
}

function cote() {
  var braz = document.getElementById("cot");
  if (braz.style.display === "none") {
    braz.style.display = "block";
  } else {
    braz.style.display = "none";
  }
}

function cotes() {
  var braz = document.getElementById("cots");
  if (braz.style.display === "none") {
    braz.style.display = "block";
  } else {
    braz.style.display = "none";
  }
}






/////Form from here
var _nextId = 1;
var _activeId = 0;

function addData() {
    var a=document.forms["myform1"]["fullname"].value;
	var b=document.forms["myform1"]["address"].value;
	var c=document.forms["myform1"]["email"].value;
	var d=document.forms["myform1"]["phone"].value;
	
	if ($("#dataTable tbody").length == 0) {
      $("#dataTable").append("<tbody></tbody>");
    }
      
  
    $("#dataTable tbody").append(
      "<tr>" +
        "<td>"+ a +"</td>" +
        "<td>"+ b +"</td>" +
        "<td>"+ c +"</td>" +
        "<td>"+ d +"</td>" +
        "<td><button class='btn btn-danger' onclick='delete()'>x</button</td>" +
      "</tr>"
      );
    
  }

$(document).ready(function() {
  productsAdd();
});